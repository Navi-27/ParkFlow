﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkFlow.Infraestructure
{
    internal class RepositoryViviendas
    {
        //falta crearla
    }
}
